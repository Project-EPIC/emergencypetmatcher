:mod:`son_manipulator` -- Manipulators that can edit SON documents as they are saved or retrieved
=================================================================================================

.. automodule:: pymongo.son_manipulator
   :synopsis: Manipulators that can edit SON documents as they are saved or retrieved
   :members:
